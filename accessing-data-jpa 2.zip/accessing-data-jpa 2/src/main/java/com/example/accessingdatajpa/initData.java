package com.example.accessingdatajpa;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class initData {

    private static final Logger log = LoggerFactory.getLogger(initData.class);

    @Bean
    CommandLineRunner initDatabase(CustomerRepository repository) {

        return args -> {
            log.info("Preloading " + repository.save(new Customer("zirong1", "yu1")));
            log.info("Preloading " + repository.save(new Customer("zirong2", "yu2")));
        };
    }
}
