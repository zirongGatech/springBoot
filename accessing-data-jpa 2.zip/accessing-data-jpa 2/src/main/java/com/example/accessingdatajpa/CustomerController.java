package com.example.accessingdatajpa;

import java.util.List;

import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
    Logger log = LoggerFactory.getLogger(AccessingDataJpaApplication.class);

    private final CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    @GetMapping("/customers")
    List<Customer> all() {
        log.info(() ->"====get all customer====");
        return service.getAll();
    }

    @PostMapping("/customers")
    Customer postNewCustomer(@RequestBody Customer newCustomer) {
        log.info(() ->"====post customer====");
        return service.postNewCustomer(newCustomer);
    }

    @GetMapping("/customers/{id}")
    Customer one(@PathVariable Long id) {
        return service.getOne(id);
    }

    @PutMapping("/customers/{id}")
    Customer putCustomer(@RequestBody Customer newCustomer, @PathVariable Long id) {
        return service.putCustomer(newCustomer, id);
    }

    @DeleteMapping("/customers/{id}")
    void deleteCustomer(@PathVariable Long id) {
        service.deleteCustomer(id);
    }
}
