package com.example.accessingdatajpa;

import static org.assertj.core.api.Assertions.assertThat;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@SpringBootTest
@AutoConfigureMockMvc
public class ControllerTests {

    Logger log = LoggerFactory.getLogger(AccessingDataJpaApplication.class);

    @Autowired
    private CustomerController controller;

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void contextLoad() throws Exception{
        assertThat(controller).isNotNull();
    }

    @Test
    public void getTest() throws Exception {
        List<Customer> customers = controller.all();
        assertEquals(2, customers.size());
    }

    @Test
    public void deleteTest() throws Exception {
        controller.deleteCustomer(Long.valueOf("1"));
        List<Customer> customers = controller.all();
        assertEquals(1, customers.size());
    }


}
