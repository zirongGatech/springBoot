package com.example.accessingdatajpa;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@SpringBootTest
class ServiceTests {

	Logger log = LoggerFactory.getLogger(AccessingDataJpaApplication.class);

	@InjectMocks
	private CustomerService service;

	@Test
	public void serviceNotNull() throws Exception {
		log.info(() ->"===service not null test===");
		assertThat(service).isNotNull();
		// TODO remove, unnecessary now
	}

	@Test
	public void customerCheckInit() throws Exception {
		List<Customer> customers = service.getAll();
		assertEquals(2, customers.size());
	}

	@Test
	public void customerADD() throws Exception {
		log.info(() ->"add customer");
		Customer customer = service.postNewCustomer(new Customer("Zirong", "Yu"));
		assertEquals("Zirong", customer.getFirstName());
		List<Customer> customers = service.getAll();
		assertEquals(3, customers.size());
		service.deleteCustomer(Long.valueOf("1"));
	}

}
